document.addEventListener('DOMContentLoaded', () => {
  const container = document.getElementById('pokemonContainer');
  const popup = document.getElementById('popupOverlay');
  const popupInfo = document.getElementById('popupInfo');
  const pokemonInPokedex = document.getElementById('pokemonInPokedex');

  if (!popup || !popupInfo || !pokemonInPokedex) {
    console.warn('Overlay elements not found; overlay cannot be shown.');
    return;
  }

  if (container) {
    container.addEventListener('click', (event) => {
      const card = event.target.closest('.pokemon-card');
      if (!card) return;

      const name = card.dataset.name || card.querySelector('h2')?.textContent || 'Unknown';
      const dex = card.dataset.dex || card.querySelector('p strong')?.parentElement?.textContent?.replace('dex nummer:', '').trim() || 'N/A';
      const type1 = card.dataset.type1 || '';
      const type2 = card.dataset.type2 || '';
      const gewicht = card.dataset.gewicht || 'N/A';
      const lengte = card.dataset.lengte || 'N/A';
      const img = card.dataset.img || card.querySelector('img')?.src || '';

      pokemonInPokedex.src = img;
      pokemonInPokedex.alt = `${name} image`;

      popupInfo.innerHTML = `
        <h2>${name}</h2>
        <p><strong>Dex nummer:</strong> ${dex}</p>
        <p><strong>Type 1:</strong> ${type1}</p>
        <p><strong>Type 2:</strong> ${type2}</p>
        <p><strong>Weight:</strong> ${gewicht}</p>
        <p><strong>Height:</strong> ${lengte}</p>
      `;

      popup.classList.add('show');
    });
  } else {
    console.warn('Pokemon container not found; overlay open trigger unavailable.');
  }

  window.addEventListener('click', (e) => {
    if (e.target === popup) {
      popup.classList.remove('show');
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' || e.key === 'Esc') {
      popup.classList.remove('show');
    }
  });
});