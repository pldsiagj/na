<?php
  $error = ""; 
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
  }
?>

<?php

require_once '../config.php';

try {
    $stmt = $pdo->query("SELECT * FROM tb_users");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    $users = [];
    $error = "Error fetching users: " . htmlspecialchars($e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <title>Login - Pokedex</title>
    <link rel="stylesheet" href="inlog.css">
</head>
<body>


        <!-- inlog formulier -->
<div class="login-container">
    <div class="pokeball"></div>
    <h1>Inloggen</h1>

    <?php if ($error != ""): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

   <form method="POST" action="pokedex.php">
        <div class="input-group">
            <label>Gebruikersnaam</label>
            <input type="text" name="username" required>
        </div>

        <div class="input-group">
            <label>Wachtwoord</label>
            <input type="password" name="password" required>
        </div>
            <button type="submit" class="login-btn" href="../admin_pagina/admin.php">Login</button>
    </form>

        <!-- inlog functionaliteit -->
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $_POST["username"];
        $password = $_POST["password"];

        foreach ($users as $user) {
            if ($user['username'] === $username && password_verify($password, $user['password'])) {
                header("Location: pokedex.php");
                exit();
            }
        }

        $error = "Ongeldige gebruikersnaam of wachtwoord.";
    }
    ?>
</div>

</body>
</html>