<?php

require_once 'config.php';

try {
    $stmt = $pdo->query("SELECT * FROM tb_pokemon ORDER BY id ASC");
    $pokemon = $stmt->fetchAll();
} catch (PDOException $e) {
    $pokemon = [];
    $error = "Error fetching pokémon: " . htmlspecialchars($e->getMessage());
}

try {
    $stmt_types = $pdo->query("
      SELECT DISTINCT type1 AS type FROM tb_pokemon
      UNION
      SELECT DISTINCT type2 AS type FROM tb_pokemon
      WHERE type2 IS NOT NULL AND type2 != ''
      ORDER BY type
    ");
    $types = $stmt_types->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $types = [];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Pokédex</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Syne:wght@400..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class= "nav_bar">
<form action="index.php" class="nav-form">

<div class="nav-left">
  <select id="pageSelect" onchange="navigateToPage(this.value)">
    <option value="">-- Select Page --</option>
    <option value="index.php">Mainpage</option>
    <option value="inlog/inlog.php">Login</option>
    <option value="register.php">Create an Account</option>
    <option value="admin_pagina/admin.php">Admin</option>
  </select>
</div>

<div class="nav-center">
      <div id="typeFilters">
        <label for="typeSelect">Filter by Type:</label>
        <select id="typeSelect" onchange="filterPokemon(this.value)">
          <option value="all">All</option>
          <?php foreach ($types as $type): ?>
            <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

<script>
function navigateToPage(page) {
  if (page) {
    window.location.href = page;
  }
}
</script>

<div class="nav-right">
      <label for="search-bar" class="visually-hidden">Search</label>
      <input id="search-bar" type="text" name="search" placeholder="...">
      <button id="search-button" type="submit">Zoeken</button>
    </div>
  </form>
</div>

<!-- <label>
<input id="search-bar" type="text" name="search" placeholder="...">
</label>
<button id="search-button" type="submit">Zoeken</button>
</form> -->

</div>
    <div id = "pokedex-logo">
        <br><br><br><br><br>
        <img class="pokedex-logo" src="img/Pokedex_logo.png" alt="naam">
        <?php if (isset($error)): ?>
    </div>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    
    <?php if (!empty($pokemon)): ?>
        <div class="pokemon-container" id="pokemonContainer">
            <?php foreach ($pokemon as $poke): ?>
                <div class="pokemon-card type-<?php echo strtolower(str_replace(' ', '-', e($poke['type1']))); ?> type2-<?php echo strtolower(str_replace(' ', '-', e($poke['type2']))); ?>" data-name="<?php echo e($poke['name']); ?>" data-dex="<?php echo e($poke['dex_number']); ?>" data-type1="<?php echo e($poke['type1']); ?>" data-type2="<?php echo e($poke['type2']); ?>" data-img="img/<?php echo e($poke['img']); ?>" data-gewicht="<?php echo e($poke['weight']); ?>" data-lengte="<?php echo e($poke['height']); ?>">
                    <img src="img/<?php echo e($poke['img']); ?>" alt="<?php echo e($poke['name']); ?> Image" style="width: 200px; height: 200px; display: block; margin: 0 auto 10px;">
                    <h2 class="text"><?php echo e($poke['name']); ?></h2>
                    <p><strong>Dex nummer:</strong> <?php echo e($poke['dex_number']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No Pokémon found in database.</p>
    <?php endif; ?>
        <div id="popupOverlay" class="overlay">
            <div id ="popupWrap">
                <div class="popup-content">
                    <div class="popup-left">
                        <div class="pokedex-frame">
                            <img src="img/pokedexbg.jpg" alt="pokedexbg" id="pokedexbg" class="pokedex-bg">
                            <img src="" alt="pokemon" id="pokemonInPokedex" class="pokemon-in-pokedex">
                        </div>
                    </div>
                <div id="popupInfo" class="popup-info"></div>
            </div>
        </div>
    </div>

<script>
function filterPokemon(type) {
    const cards = document.querySelectorAll('.pokemon-card');
    cards.forEach(card => {
        if (type === 'all') {
            card.classList.add('show');
            card.style.display = '';
        } else {
            const typeClass = type.toLowerCase().replace(/ /g, '-');
            const hasType1 = card.classList.contains(`type-${typeClass}`);
            const hasType2 = card.classList.contains(`type2-${typeClass}`);
            if (hasType1 || hasType2) {
                card.classList.add('show');
                card.style.display = '';
            } else {
                card.classList.remove('show');
                card.style.display = 'none';
            }
        }
    });
}

window.addEventListener('DOMContentLoaded', () => {
    filterPokemon('all');
});
</script>

<script src="script.js"></script>
</body>
</html>
