<?php

require_once 'config.php';

try {
    $stmt = $conn->query("SELECT * FROM tb_pokemon ORDER BY id ASC");
    $pokemon = $stmt->fetchAll();
} catch (PDOException $e) {
    $pokemon = [];
    $error = "Error fetching pokémon: " . htmlspecialchars($e->getMessage());
}

try {
    $stmt_types = $conn->query("SELECT DISTINCT `type 1` as type FROM tb_pokemon UNION SELECT DISTINCT `type 2` as type FROM tb_pokemon WHERE `type 2` IS NOT NULL AND `type 2` != '' ORDER BY type");
    $types = $stmt_types->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    $types = [];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Pokédex</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Syne:wght@400..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    
</head>

<body>

<div class="nav_bar">
  <form action="index.php" class="nav-form">





<div class="nav-left">
  <select id="pageSelect" onchange="navigateToPage(this.value)">
    <option value="">-- Select Page --</option>
    <option value="index.php">Mainpage</option>
    <option value="login.php">Login</option>
    <option value="register.php">Create an Account</option>
    <option value="admin.php">Admin</option>
  </select>
</div>


    <div class="nav-center">
      <div id="typeFilters">
        <label for="typeSelect">Filter by Type:</label>
        <select id="typeSelect" onchange="filterPokemon(this.value)">
          <option value="all">All</option>
          <?php foreach ($types as $type): ?>
            <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>

<script>
function navigateToPage(page) {
  if (page) {
    window.location.href = page;
  }
}
</script>

    <div class="nav-right">
      <label for="search-bar" class="visually-hidden">Search</label>
      <input id="search-bar" type="text" name="search" placeholder="...">
      <button id="search-button" type="submit">Zoeken</button>

  
    </div>
  </form>
</div>


    <div id = "pokedex-logo">
        <br><br><br><br><br>
        <img class="pokedex-logo" src="Pokedex_logo.png" alt="naam">
        <?php if (isset($error)): ?>
    </div>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    
<br><br><br>

    <?php if (!empty($pokemon)): ?>
        <div class="pokemon-container">
            <?php foreach ($pokemon as $poke): ?>
                <div class="pokemon-card show type-<?php echo strtolower(str_replace(' ', '-', e($poke['type 1']))); ?> type2-<?php echo strtolower(str_replace(' ', '-', e($poke['type 2']))); ?>">
                    <img src="img/<?php echo e($poke['img']); ?>" alt="<?php echo e($poke['naam']); ?> Image" style="width: 200px; height: 200px; display: block; margin: 0 auto 10px;">
                    <h2 class="text"><?php echo e($poke['naam']); ?></h2>
                    <p><strong>dexnumber:</strong> <?php echo e($poke['dexnumber']); ?></p>
                    <p><strong>Type 1:</strong> <?php echo e($poke['type 1']); ?></p>
                    <p><strong>Type 2:</strong> <?php echo e($poke['type 2']); ?></p>
                    <p><strong>Gewicht:</strong> <?php echo e($poke['gewicht']); ?></p>
                    <p><strong>Lengte:</strong> <?php echo e($poke['lengte']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No Pokémon found in database.</p>
    <?php endif; ?>
<script>
function filterPokemon(type) {
    const cards = document.querySelectorAll('.pokemon-card');
    cards.forEach(card => {
        if (type === 'all') {
            card.classList.add('show');
        } else {
            const typeClass = type.toLowerCase().replace(/ /g, '-');
            const hasType1 = card.classList.contains(`type-${typeClass}`);
            const hasType2 = card.classList.contains(`type2-${typeClass}`);
            if (hasType1 || hasType2) {
                card.classList.add('show');
            } else {
                card.classList.remove('show');
            }
        }
    });
}
</script>


<p>p diddy </p>


</body>
</html>
