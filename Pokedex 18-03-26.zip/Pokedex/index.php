<?php

require_once 'config.php';

try {
    $stmt = $conn->query("SELECT * FROM tb_pokemon ORDER BY id ASC");
    $pokemon = $stmt->fetchAll();
} catch (PDOException $e) {
    $pokemon = [];
    $error = "Error fetching pokémon: " . htmlspecialchars($e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Pokédex</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Syne:wght@400..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>




<div class= "nav_bar">

<form action="index.php">
<label>
<input id="search-bar" type="text" name="search" placeholder="...">
</label>
<button id="search-button" type="submit">Zoeken</button>
</form>


</div>


    <div id = "pokedex-logo">
        <br><br><br><br><br>
        <img class="pokedex-logo" src="Pokedex_logo.png" alt="naam">
        <?php if (isset($error)): ?>
    </div>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
    
    <?php if (!empty($pokemon)): ?>
        <div class="pokemon-container" id="pokemonContainer">
            <?php foreach ($pokemon as $poke): ?>
                <div class="pokemon-card type-<?php echo strtolower(str_replace(' ', '-', e($poke['type1']))); ?> type2-<?php echo strtolower(str_replace(' ', '-', e($poke['type2']))); ?>" data-name="<?php echo e($poke['name']); ?>" data-dex="<?php echo e($poke['dex_number']); ?>" data-type1="<?php echo e($poke['type1']); ?>" data-type2="<?php echo e($poke['type2']); ?>" data-img="img/<?php echo e($poke['img']); ?>" data-gewicht="<?php echo e($poke['weight']); ?>" data-lengte="<?php echo e($poke['height']); ?>">
                    <img src="img/<?php echo e($poke['img']); ?>" alt="<?php echo e($poke['name']); ?> Image" style="width: 200px; height: 200px; display: block; margin: 0 auto 10px;">
                    <h2 class="text"><?php echo e($poke['name']); ?></h2>
                    <p><strong>Dex nummer:</strong> <?php echo e($poke['dex_number']); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No Pokémon found in database.</p>
    <?php endif; ?>
        <div id="popupOverlay" class="overlay">
            <div id ="popupWrap">
                <div class="popup-content">
                    <div class="popup-left">
                        <div class="pokedex-frame">
                            <img src="pokedexbg.jpg" alt="pokedexbg" id="pokedexbg" class="pokedex-bg">
                            <img src="" alt="pokemon" id="pokemonInPokedex" class="pokemon-in-pokedex">
                        </div>
                    </div>
                <div id="popupInfo" class="popup-info"></div>
            </div>
        </div>
    </div>
<script src="script.js"></script>
</body>
</html>
